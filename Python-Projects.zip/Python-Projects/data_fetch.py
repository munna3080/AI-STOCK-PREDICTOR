import yfinance as yf
import pandas as pd

def fetch_stock_data(ticker="RELIANCE.NS", period="5y"):
    print(f"📥 Fetching {ticker} data from Yahoo Finance...")
    data = yf.download(ticker, period=period, progress=False)
    if isinstance(data.columns, pd.MultiIndex):
        data.columns = data.columns.get_level_values(0)
    data = data[['Close']].dropna()
    print(f"✅ Downloaded {len(data)} days of data")
    return data

if __name__ == "__main__":
    df = fetch_stock_data()
    df.to_csv("stock_data.csv")
    
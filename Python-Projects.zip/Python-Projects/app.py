import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import joblib
from data_fetch import fetch_stock_data

st.set_page_config(page_title="AI Stock Predictor", layout="wide")
st.title("📈 AI Stock Market Price Predictor")
st.markdown("**LSTM Deep Learning Model** | Next-day & 7-day forecast | Built for Deloitte Portfolio")

# Sidebar
ticker = st.sidebar.text_input("Enter Stock Ticker (e.g. RELIANCE.NS, TCS.NS, AAPL)", "RELIANCE.NS")
days_to_predict = st.sidebar.slider("Forecast Horizon (days)", 1, 7, 1)

if st.sidebar.button("🚀 Predict"):
    with st.spinner("Fetching latest data & loading model..."):
        from tensorflow.keras.models import load_model

        df = fetch_stock_data(ticker, period="5y")
        model = load_model("stock_predictor_model.keras")
        scaler = joblib.load("scaler.pkl")

        # Prepare last 60 days
        last_60 = df['Close'].values[-60:].reshape(-1, 1)
        last_60_scaled = scaler.transform(last_60)

        # Predict next days (recursive)
        predictions = []
        current_seq = last_60_scaled.copy()

        for _ in range(days_to_predict):
            pred_scaled = model.predict(current_seq.reshape(1, 60, 1), verbose=0)
            predictions.append(scaler.inverse_transform(pred_scaled)[0][0])
            current_seq = np.append(current_seq[1:], pred_scaled, axis=0)

        # Plot
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=df.index[-100:], y=df['Close'][-100:], name="Actual Price", line=dict(color="blue")))
        future_dates = pd.date_range(start=df.index[-1], periods=days_to_predict+1, freq='B')[1:]
        fig.add_trace(go.Scatter(x=future_dates, y=predictions, name="AI Prediction", line=dict(color="red", dash="dash")))

        st.plotly_chart(fig, use_container_width=True)

        st.success(f"**Next Day ({future_dates[0].date()}) Predicted Price: ₹{predictions[0]:.2f}**")
        if days_to_predict > 1:
            st.write("**7-Day Forecast**:" if days_to_predict==7 else f"**{days_to_predict}-Day Forecast**:")
            for i, price in enumerate(predictions, 1):
                st.write(f"Day +{i}: ₹{price:.2f}")

st.sidebar.info("💡 Tip: Use Indian stocks like RELIANCE.NS, HDFCBANK.NS, INFY.NS")

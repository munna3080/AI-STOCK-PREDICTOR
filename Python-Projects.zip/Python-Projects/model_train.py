import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping
import joblib

# Load data
df = pd.read_csv("stock_data.csv", index_col=0)
prices = df['Close'].values.reshape(-1, 1)

# Scale data
scaler = MinMaxScaler()
scaled_prices = scaler.fit_transform(prices)
joblib.dump(scaler, "scaler.pkl")

# Create sequences (60 days → predict next day)
SEQ_LENGTH = 60
X, y = [], []
for i in range(len(scaled_prices) - SEQ_LENGTH):
    X.append(scaled_prices[i:i+SEQ_LENGTH])
    y.append(scaled_prices[i+SEQ_LENGTH])

X, y = np.array(X), np.array(y)

# Train-test split (80-20)
split = int(0.8 * len(X))
X_train, X_test = X[:split], X[split:]
y_train, y_test = y[:split], y[split:]

# Build LSTM Model
model = Sequential([
    LSTM(50, return_sequences=True, input_shape=(SEQ_LENGTH, 1)),
    Dropout(0.2),
    LSTM(50),
    Dropout(0.2),
    Dense(1)
])

model.compile(optimizer='adam', loss='mean_squared_error')
early_stop = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)

print("🚀 Training LSTM model...")
model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test),
          callbacks=[early_stop], verbose=1)

# Save
model.save("stock_predictor_model.keras")
print("✅ Model trained & saved! (stock_predictor_model.keras)")

# Quick evaluation
from sklearn.metrics import mean_absolute_error, mean_squared_error
pred_scaled = model.predict(X_test)
pred = scaler.inverse_transform(pred_scaled)
actual = scaler.inverse_transform(y_test)
print(f"📊 Test MAE: ₹{mean_absolute_error(actual, pred):.2f}")
print(f"📊 Test RMSE: ₹{mean_squared_error(actual, pred)**0.5:.2f}")
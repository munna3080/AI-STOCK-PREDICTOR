# AI Stock Market Price Predictor (LSTM)
End-to-end Deep Learning project using TensorFlow, yfinance & Streamlit

## Features
- Fetches live data from Yahoo Finance
- LSTM model (60-day sequence)
- Next-day + 7-day forecast
- Interactive Streamlit dashboard
- MAE/RMSE metrics

## Tech: Python, TensorFlow, Pandas, yfinance, Streamlit

Live Demo: [Your Replit URL]
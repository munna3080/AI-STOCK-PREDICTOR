import streamlit as st

st.title("My App")
st.write("Your Streamlit app is ready. Start building!")

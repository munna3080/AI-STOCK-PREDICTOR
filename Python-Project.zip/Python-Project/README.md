Name : Shaik.Munna
Email id : munna40130@gmail.com
College name : Vasavi College of Engineering-VCE
Selected Skill Track : AI & Machine Learning -> Python
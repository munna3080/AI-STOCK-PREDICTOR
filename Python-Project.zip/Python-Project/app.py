import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import joblib
from data_fetch import fetch_stock_data

st.set_page_config(page_title="AI Stock Predictor", layout="wide")
st.title("📈 AI Stock Market Price Predictor")
st.markdown("**LSTM Deep Learning Model** | Next-day & 7-day forecast | Built for Deloitte Portfolio")

# Sidebar
ticker = st.sidebar.text_input("Enter Stock Ticker (e.g. RELIANCE.NS, TCS.NS, AAPL)", "RELIANCE.NS")
days_to_predict = st.sidebar.slider("Forecast Horizon (days)", 1, 7, 1)

if st.sidebar.button("🚀 Predict"):
    with st.spinner("Fetching latest data & loading model..."):
        from tensorflow.keras.models import load_model

        df = fetch_stock_data(ticker.strip().upper(), period="5y")

        if df.empty or len(df) < 60:
            st.error(f"❌ Not enough data for **{ticker}**. Please check the ticker symbol and try again.\n\n"
                     "Examples: `RELIANCE.NS`, `TCS.NS`, `HDFCBANK.NS`, `INFY.NS`, `AAPL`")
        else:
            model = load_model("stock_predictor_model.keras")
            scaler = joblib.load("scaler.pkl")

            # Prepare last 60 days
            last_60 = df['Close'].values[-60:].reshape(-1, 1)
            last_60_scaled = scaler.transform(last_60)

            # Predict next days (recursive)
            predictions = []
            current_seq = last_60_scaled.copy()

            for _ in range(days_to_predict):
                pred_scaled = model.predict(current_seq.reshape(1, 60, 1), verbose=0)
                predictions.append(scaler.inverse_transform(pred_scaled)[0][0])
                current_seq = np.append(current_seq[1:], pred_scaled, axis=0)

            # Plot
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=df.index[-100:], y=df['Close'][-100:], name="Actual Price", line=dict(color="blue")))
            future_dates = pd.date_range(start=df.index[-1], periods=days_to_predict+1, freq='B')[1:]
            fig.add_trace(go.Scatter(x=future_dates, y=predictions, name="AI Prediction", line=dict(color="red", dash="dash")))
            fig.update_layout(title=f"{ticker.strip().upper()} — Price Prediction", xaxis_title="Date", yaxis_title="Price (₹)")

            st.plotly_chart(fig, width='stretch')

            st.success(f"**Next Day ({future_dates[0].date()}) Predicted Price: ₹{predictions[0]:.2f}**")
            if days_to_predict > 1:
                label = "**7-Day Forecast**:" if days_to_predict == 7 else f"**{days_to_predict}-Day Forecast**:"
                st.write(label)
                for i, price in enumerate(predictions, 1):
                    st.write(f"Day +{i}: ₹{price:.2f}")

st.sidebar.info("💡 Tip: Use Indian stocks like RELIANCE.NS, HDFCBANK.NS, INFY.NS")
